szamolo = 0

document.getElementById("uj-sor").onclick=function(){
    feladat_neve = document.getElementById("feladat-neve").value
    szamolo++
    document.getElementById("ide-rakom-a-dolgokat").innerHTML += 
    `<div id="${feladat_neve[1]}${feladat_neve[2]}${feladat_neve[0]}${feladat_neve[feladat_neve.length-1]}${szamolo}" class="feladat-sor">
        <h3>${feladat_neve}</h3>
        <div id="feladat-fejlec">
            <input placeholder="Alfeladat neve"></input>
            <input type="date" placeholder="Alfeladat idöhatára"></input>
            <button onclick="AlfeladatLetrehozasa(event)">🖊️</button>
            <button onclick="Helycsere(event,'fel')">⬆️</button>
            <button onclick="Helycsere(event,'le')">⬇️</button>
            <button onclick="FeladatKesz(event,true)">✔️</button>
            <button onclick="FeladatKesz(event,false)">❌</button>
            <button onclick="Torles(event)">🗑️</button>
        </div>
        <div class="alfeladatok">
            
        </div>
    </div>`
}

function AlfeladatLetrehozasa(event){
    console.log(event.target.parentElement.parentElement.childNodes[5])
    console.log(event.target.parentElement.childNodes[1])
    console.log(event.target.parentElement.childNodes[3].value)
    let mai_datum = new Date(new Date().toLocaleDateString("hu-HU"))
    let valasztott_datum = new Date(event.target.parentElement.childNodes[3].value)


    if(event.target.parentElement.childNodes[3].value == ""){
        event.target.parentElement.parentElement.childNodes[5].innerHTML += 
        `<div id="alfeladat">
            <p>${event.target.parentElement.childNodes[1].value}</p>
            <button onclick="AlfeladatKesz(event,true)">✔️</button>
            <button onclick="AlfeladatKesz(event,false)">❌</button>
            <button onclick="AlfeladatTorles(event)">🗑️</button>
            <p id="kesz-statusz">false</p>
        </div>`
    }
    else{
        event.target.parentElement.parentElement.childNodes[5].innerHTML += 
        `<div id="alfeladat">
            <p>${event.target.parentElement.childNodes[1].value}</p>
            <button onclick="AlfeladatKesz(event,true)">✔️</button>
            <button onclick="AlfeladatKesz(event,false)">❌</button>
            <button onclick="AlfeladatTorles(event)">🗑️</button>
            <p>${Math.round((valasztott_datum.getTime()-mai_datum.getTime()) / (1000 * 3600 * 24))} nap van hátra az alfeladat teljesitéséhez</p>
            <p id="kesz-statusz">false</p>
        </div>`
    }
    console.log(mai_datum)
}

function FeladatKesz(event,bool){
    if(bool == true){
        event.target.parentElement.style.backgroundColor = "green"
        event.target.parentElement.parentElement.childNodes[5].style.display = "none"
    }
    if(bool == false){
        event.target.parentElement.style.backgroundColor = "red"
        event.target.parentElement.parentElement.childNodes[5].style.display = "grid"
    }
}

function AlfeladatKesz(event,bool){
    if(bool == true){
        event.target.parentElement.style.backgroundColor = "green"
        event.target.parentElement.childNodes[11].innerHTML = "true"
    }
    if(bool == false){
        event.target.parentElement.style.backgroundColor = "red"
        event.target.parentElement.childNodes[11].innerHTML = "false"
    }
}

function Torles(event){
    event.target.parentElement.parentElement.remove()
}

function AlfeladatTorles(event){
    event.target.parentElement.remove()
}