document.getElementById("uj-sor").onclick=function(){
    feladat_neve = document.getElementById("feladat-neve").value
    
    document.getElementById("ide-rakom-a-dolgokat").innerHTML += 
    
    `<div class="feladat-sor">
            <h3>${feladat_neve}</h3>
            <div id="feladat-fejlec">
                <button>🖊️</button>
                <button>⬆️</button>
                <button>⬇️</button>
                <button>✔️</button>
                <button>❌</button>
            </div>
             
        </div>` 

}